# MASTER VS CODE AGENT PROMPT — Intel Physical AI Challenge

Repository:
https://github.com/HARIScyber/Intel-Physical-AI-Challenge-.git

Goal:
Make the existing project genuinely runnable end-to-end for the MuJoCo dinner-table task and produce a truthful 3–5 minute MP4 demonstration. Do NOT fake success, disable collision/physics, teleport objects, or mark actions successful because a command was issued.

IMPORTANT:
- Work from the existing repository. Do not rewrite the project from scratch.
- Preserve the current architecture where practical.
- Run tests after every logical group of fixes.
- Never use placeholder VLA checkpoint paths as real model IDs.
- If a real VLA checkpoint is not available, keep the VLA stage explicitly unavailable and run the verified scripted baseline. Do not claim VLA completion.
- The final video must show actual simulator output and actual verifier status.

PHASE 1 — AUDIT
1. Inspect every Python/config/documentation file under:
   simulation/, control/, perception/, language/, planning/, policy/,
   evaluation/, optimization/, project_datasets/, scripts/, tests/.
2. Search for:
   - `return True` in verification/contact code
   - TODO/FIXME/NotImplemented
   - duplicate functions
   - placeholder checkpoint paths
   - inconsistent arm labels A/B/a/b
   - multiple success criteria
   - state-history reconstruction
   - gripper/object contact checks
   - action-space vs control-vector dimension mismatches
   - camera/render/video code
3. Run:
   python -m compileall -q physical_ai simulation perception language planning policy control evaluation optimization project_datasets scripts
   python -m unittest discover -s tests
   python scripts/setup_check.py

PHASE 2 — CRITICAL PHYSICS FIXES
A. simulation/mujoco_env.py
- REMOVE the unconditional:
    return True
  from `_is_gripper_contacting_object`.
- Determine contact from actual MuJoCo contacts:
  - identify geom IDs belonging to arm A/B gripper fingers
  - identify the object's actual geom IDs
  - return True only if the selected arm's gripper geom is in contact with the requested object's geom.
- Do not treat arbitrary arm/object contact as a valid grasp.
- Keep wrong-object and arm/table collisions unsafe.
- Make selected-arm contact explicit.

B. simulation/scene.py
- Fix grasp-site frame alignment.
- The `arm_*_grasp_site` must be physically centered between the two fingers.
- Remove the `0 0 {0.10 * side}` asymmetry unless proven correct by geometry.
- Add a clear, documented local grasp frame.
- Make A and B use the same gripper geometry convention, mirrored only by base placement.

C. policy/base_policy.py
- Compute grasp targets from actual MuJoCo object pose and geometry.
- Spoon/fork: target the HANDLE, not the bowl/head.
- Use object quaternion to rotate local handle offsets into world coordinates.
- Use a pregrasp pose, grasp pose, and lift pose.
- Never use SAFE_POSE as a successful IK fallback.
- If IK fails, return structured failure.
- Use one arm-assignment source of truth.

D. scripts/run_demo.py
- A failed grasp MUST prevent transport/release/place.
- On failed grasp:
  1. mark FAILED
  2. move to safe recovery pose
  3. retry with bounded retry count
  4. re-observe
  5. re-plan
  6. fail the episode if retries are exhausted
- Do not simply continue the original sequence.

PHASE 3 — REAL STATE HISTORY
Replace `ManipulationStateMachine.get_history()` logic that reconstructs all previous states from the current enum value.

Track an actual event log:
    state_history[object].append({
        "state": "...",
        "timestamp": ...,
        "reason": ...
    })

TaskVerifier must verify that every required state actually occurred in the event log.

Use a single vocabulary:
located
pregrasp
approaching
grasping
grasped
lifting
transporting
preplacing
releasing
placed
verified

Do not invent `approached`/`lifted`/etc. names that differ from the state machine without a mapping.

PHASE 4 — REAL GRASP VERIFICATION
For each grasp:
1. Confirm selected gripper/object contact from MuJoCo.
2. Record object position.
3. Close gripper.
4. Settle physics for several steps.
5. Lift the selected arm.
6. Confirm object follows the gripper for multiple physics steps.
7. Confirm object displacement is consistent with being held.
8. Only then set GRASPED/LIFTING.

For release:
1. Move to target.
2. Open gripper.
3. Let object settle.
4. Confirm object remains in the placement region.
5. Confirm gripper is no longer holding it.
6. Only then set PLACED/VERIFIED.

PHASE 5 — GENUINE BIMANUAL EXECUTION
The dinner-table task must actually exercise both arms.

Do not count a `requires_bimanual=True` flag as bimanual behavior.

At minimum:
- Arm A manipulates one or more objects.
- Arm B manipulates one or more objects.
- Record per-arm action counts.
- Record at least one time interval where both arm command vectors are actively controlled in the same execution cycle.
- If the task design requires cooperative manipulation, use the existing BimanualController and verify both arms physically move.
- Add a runtime metric:
    bimanual_control_cycles
  that increments only when both arm commands are non-hold commands.

PHASE 6 — TASK VERIFIER
TaskVerifier must be the only authoritative success checker.

Required success:
- drawer open if the task requires it
- plate placed correctly
- cup placed correctly
- spoon placed correctly
- fork placed correctly
- no unsafe collision
- every object's actual event history contains required manipulation states
- if bimanual is required, actual bimanual execution evidence exists

Do not require napkin/bowl unless they are part of the actual command/task.

PHASE 7 — RANDOMIZED EVALUATION
Run seeds 0..9.

For every seed save:
- success/failure
- action count
- failed grasps
- retries
- collisions
- bimanual cycles
- per-object final position/orientation
- runtime
- verifier reasons

Create:
outputs/evaluation/seed_results.json
outputs/evaluation/summary.json

Do not report 10/10 unless all 10 are actually executed.

PHASE 8 — DATASET
Only after the scripted baseline is physically valid:
- regenerate demonstrations from successful episodes
- ensure each episode has synchronized camera frames, actions, language, states
- validate the dataset
- convert to LeRobot format using the installed/current API
- remove duplicate helper definitions

PHASE 9 — VLA
Only use a real compatible LeRobot checkpoint.
- Distinguish local paths from Hugging Face model IDs.
- Validate model/task/observation/action compatibility before inference.
- If no real checkpoint is configured, fail explicitly or use scripted fallback with a clear status.
- Never initialize a model from `/path/to/...` placeholders.
- Add VLA lifecycle:
  UNINITIALIZED -> LOADING -> READY
  or FAILED/UNAVAILABLE/FALLBACK.
- Never call predict() before READY.

PHASE 10 — OPENVINO
- Keep conversion separate from simulation correctness.
- Convert only a real supported model/checkpoint.
- Run OpenVINO inference on the actual target device available on the machine.
- Report CPU/NPU device name, latency, throughput and memory if available.
- If no Intel NPU is present, report CPU benchmark and mark NPU benchmark unavailable; do not fabricate numbers.

PHASE 11 — VIDEO
Create:
scripts/make_demo_video.py

Requirements:
- headless MuJoCo camera capture
- overhead + front views
- natural-language instruction
- phase/action overlay
- seed
- collision count
- actual verifier state
- final SUCCESS or NOT VERIFIED based only on simulator/verifier
- 3–5 minutes total
- MP4 output under outputs/videos/
- use OpenCV VideoWriter or another installed local encoder
- do not fake a success screen
- video command:
  python scripts/make_demo_video.py --seed 0 --minutes 3.5

PHASE 12 — FINAL COMMANDS
Run:
python -m compileall -q physical_ai simulation perception language planning policy control evaluation optimization project_datasets scripts
python -m unittest discover -s tests
python scripts/setup_check.py
python scripts/run_demo.py --policy scripted --seed 0 --headless
python scripts/run_demo.py --policy scripted --seed 1 --headless
...
python scripts/run_demo.py --policy scripted --seed 9 --headless
python scripts/make_demo_video.py --seed 0 --minutes 3.5

Then report:
- exact files changed
- tests passed/failed
- seed 0..9 results
- final task success
- real bimanual evidence
- VLA status
- OpenVINO status
- exact video path
- any remaining blocker

Never claim something was run if it was not run.
