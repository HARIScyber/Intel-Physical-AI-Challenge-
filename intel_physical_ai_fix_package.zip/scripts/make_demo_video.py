"""Create a truthful 3–5 minute MP4 from the real MuJoCo simulation.

Run:
    python scripts/make_demo_video.py --seed 0 --minutes 3.5

The script intentionally does not invent a success result. The final frame is
based on the real TaskVerifier result.
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from physical_ai.config import load_config
from simulation import BimanualMujocoEnv
from language import parse_instruction, reason_about_task
from perception import CameraProcessor
from planning import TaskPlanner
from policy.base_policy import ScriptedPolicy
from evaluation.task_verifier import TaskVerifier


def compose(overhead, front, title, subtitle):
    canvas = np.zeros((720, 1280, 3), dtype=np.uint8)
    canvas[:480, :640] = cv2.resize(overhead, (640, 480))
    canvas[:480, 640:] = cv2.resize(front, (640, 480))
    cv2.putText(canvas, "OVERHEAD", (20, 515), 0, 0.7, (255,255,255), 2)
    cv2.putText(canvas, "FRONT", (660, 515), 0, 0.7, (255,255,255), 2)
    cv2.putText(canvas, title[:110], (20, 560), 0, 0.65, (255,255,255), 2)
    cv2.putText(canvas, subtitle[:145], (20, 605), 0, 0.55, (220,220,220), 1)
    cv2.putText(canvas, "Intel Physical AI Challenge | MuJoCo | Bimanual SO-101",
                (20, 660), 0, 0.52, (220,220,220), 1)
    return canvas


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--minutes", type=float, default=3.5)
    p.add_argument("--fps", type=int, default=10)
    p.add_argument("--output", type=Path, default=None)
    args = p.parse_args()

    minutes = max(3.0, min(5.0, args.minutes))
    fps = max(5, min(20, args.fps))
    total_frames = int(minutes * 60 * fps)

    out = args.output or ROOT / "outputs" / "videos" / f"dinner_table_seed{args.seed}.mp4"
    out.parent.mkdir(parents=True, exist_ok=True)

    cfg = load_config()
    env = BimanualMujocoEnv(cfg)
    writer = None
    try:
        obs, _ = env.reset(seed=args.seed)
        instruction = "Set the dinner table."
        command = reason_about_task(parse_instruction(instruction))
        processor = CameraProcessor(cfg.simulation.get("perception", {}),
                                    ROOT / "outputs" / "perception")
        scene = processor.perceive(obs, env.model, env.data, "overhead")
        sequence = TaskPlanner({"max_retries": 2}).plan(command, scene)
        policy = ScriptedPolicy(model=env.model, data=env.data)
        policy.reset(sequence)

        first = compose(obs["camera_images"]["overhead"],
                        obs["camera_images"]["front"],
                        "PHYSICAL AI DINNER TABLE",
                        f"Instruction: {instruction} | seed={args.seed}")
        writer = cv2.VideoWriter(str(out), cv2.VideoWriter_fourcc(*"mp4v"),
                                 fps, (first.shape[1], first.shape[0]))
        if not writer.isOpened():
            raise RuntimeError(f"Cannot open video writer: {out}")

        last_obs = obs
        action_i = 0
        collisions = 0
        start = time.perf_counter()

        # Execute the real sequence once, then keep rendering the final simulator
        # state so the final video remains 3–5 minutes without changing physics.
        while action_i < len(sequence.actions):
            action = sequence.actions[action_i]
            command_action = policy.predict(scene, instruction)
            command_action["_physics_steps"] = max(
                1, int(round(
                    1.0 /
                    float(cfg.simulation["simulation"].get("control_frequency", 20)) /
                    float(cfg.simulation["simulation"].get("timestep", 0.002))
                ))
            )
            result = env.step(command_action)
            last_obs = result[0]
            collisions += int(result[4].get("collision", False))
            scene = processor.perceive(last_obs, env.model, env.data, "overhead")
            verification = TaskVerifier(env, command).verify()
            subtitle = f"Action {action_i+1}/{len(sequence.actions)}: {action.name} | verifier={verification.success} | collisions={collisions}"
            frame = compose(last_obs["camera_images"]["overhead"],
                            last_obs["camera_images"]["front"],
                            "Set the dinner table",
                            subtitle)
            # Hold each real action frame long enough to be readable.
            hold = max(2, total_frames // max(1, len(sequence.actions) * 2))
            for _ in range(hold):
                writer.write(frame)
            action_i += 1

        verification = TaskVerifier(env, command).verify()
        final = compose(
            last_obs["camera_images"]["overhead"],
            last_obs["camera_images"]["front"],
            "FINAL: SUCCESS" if verification.success else "FINAL: NOT VERIFIED",
            f"seed={args.seed} | collisions={collisions} | runtime={time.perf_counter()-start:.1f}s"
        )
        remaining = max(1, total_frames - int(writer.get(cv2.CAP_PROP_POS_FRAMES)))
        for _ in range(remaining):
            writer.write(final)

        print(f"VIDEO={out}")
        print(f"VERIFIER_SUCCESS={verification.success}")
        return 0 if verification.success else 2
    finally:
        if writer is not None:
            writer.release()
        env.close()


if __name__ == "__main__":
    raise SystemExit(main())
